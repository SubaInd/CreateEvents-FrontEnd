import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usernpmination',
  templateUrl: './usernpmination.component.html',
  styleUrls: ['./usernpmination.component.scss']
})
export class UsernpminationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
