import { UniqueFilterPipe } from './unique-filter.pipe';

describe('UniqueFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new UniqueFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
