import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eventsdayuser',
  templateUrl: './eventsdayuser.component.html',
  styleUrls: ['./eventsdayuser.component.scss']
})
export class EventsdayuserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
