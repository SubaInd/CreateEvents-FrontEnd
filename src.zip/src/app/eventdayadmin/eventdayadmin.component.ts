import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eventdayadmin',
  templateUrl: './eventdayadmin.component.html',
  styleUrls: ['./eventdayadmin.component.scss']
})
export class EventdayadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
